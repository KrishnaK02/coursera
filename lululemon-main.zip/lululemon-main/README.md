<div align="center">
<img width="64px" src="./doc/images/favicon.ico" alt="lemon icon"/> 
</div>

<h1 align="center">Little Lemon Bistro</h1>


<div align="center">
<img src="./doc/images/site_rwd.png" alt="Little Lemon Bistro website on multiple devices"/>
</div>